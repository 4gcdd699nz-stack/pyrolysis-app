export default async function handler(req, res) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  const { base64, mediaType } = req.body;

  if (!base64 || !mediaType) {
    return res.status(400).json({ error: 'Missing base64 or mediaType' });
  }

  const prompt = `You are reading industrial gauges in a tyre pyrolysis plant. Analyse this image carefully.

Extract ALL gauge readings visible. For each gauge identify:
- What it measures (temperature in °C, pressure in bar/psi/kPa, or other)
- The current reading value
- The unit
- The gauge's min and max scale values if visible
- Confidence level (0-100) in your reading
- Whether the needle is in a danger/red zone

Also describe:
- Gauge condition (clean, dirty, damaged, obstructed)
- Any warning indicators visible
- Overall image quality for reading accuracy

Respond ONLY with a JSON object, no markdown, no explanation:
{
  "gauges": [
    {
      "type": "temperature",
      "label": "Boiler Temperature",
      "value": 420,
      "unit": "°C",
      "scale_min": 0,
      "scale_max": 900,
      "confidence": 92,
      "in_danger_zone": false
    }
  ],
  "image_quality": "good",
  "notes": "any observations about condition or challenges",
  "overall_confidence": 88
}`;

  try {
    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': process.env.ANTHROPIC_API_KEY,
        'anthropic-version': '2023-06-01'
      },
      body: JSON.stringify({
        model: 'claude-sonnet-4-20250514',
        max_tokens: 1000,
        messages: [{
          role: 'user',
          content: [
            { type: 'image', source: { type: 'base64', media_type: mediaType, data: base64 } },
            { type: 'text', text: prompt }
          ]
        }]
      })
    });

    if (!response.ok) {
      const err = await response.text();
      return res.status(500).json({ error: 'Anthropic API error', detail: err });
    }

    const data = await response.json();
    const text = data.content.map(b => b.text || '').join('');
    const clean = text.replace(/```json|```/g, '').trim();
    const parsed = JSON.parse(clean);

    return res.status(200).json(parsed);
  } catch (err) {
    return res.status(500).json({ error: 'Failed to read gauge', detail: err.message });
  }
}
